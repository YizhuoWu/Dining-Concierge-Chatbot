import json
import boto3

def connect_to_lex(message):
    client = boto3.client('lex-runtime')
    response = client.post_text(
    botName='DiningConcierge',
    botAlias='Final',
    userId='FL',
    inputText=message
    )
    
    return response['message']

def lambda_handler(event, context):
    # TODO implement
    
    
    mess = connect_to_lex(event['messages'][0]['unstructured']['text'])
    
    
    return {
        'header': {
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS, POST, GET'
        },
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!'),
        'messages': [
            {"type": "unstructured", "unstructured": {
                "text": mess
            }
            }
        ]
    }
