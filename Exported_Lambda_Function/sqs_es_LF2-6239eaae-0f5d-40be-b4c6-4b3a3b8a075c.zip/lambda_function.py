from __future__ import print_function
import boto3
from botocore.vendored import requests
from boto3.dynamodb.conditions import Key


def query_es(cuisine):
    business_ids = []
    headers = { "Content-Type": "application/json" }
    ENDPOINT = "https://search-player-henyvfwtoroqypvekowhzumssa.us-west-2.es.amazonaws.com"
    url = ENDPOINT + '/_search?q=' + cuisine
    response = requests.get(url, headers=headers, auth=("master", "Cd1998622!")).json()
    print(response)

    all_businesses = response["hits"]["hits"]
    for business in all_businesses[0:3]:
        business_ids.append(business["_source"]["business_id"])

    #Sample Result: ['XjeGryxde-tQZF_Ewu7NCw', '_qtCG5r6fvK_ujpB5A18AQ', 'IFZ3_d01uflGixWrrD8_gg']
    return business_ids

def query_from_dynamodb(business_ids):
    result = []
    dynamodb = boto3.resource('dynamodb', region_name='us-west-2')
    table = dynamodb.Table('yelp-restaurants')
    for business_id in business_ids:
        response = table.query(
            KeyConditionExpression=Key('business_id').eq(business_id) 
        )
        name_address = (response['Items'][0]['name'],response['Items'][0]['address'])
        result.append(name_address)
        
    #Sample Result: [('Kings Wok Restaurant', '1473 Bedford Ave, Brooklyn, NY 11216'), ('Woks Chinese Cuisine', '79-21 37th Ave, Jackson Heights, NY 11372')]
    return result
        


def send_sms_message(location, cuisine, num_of_people, email, date, time, dinner_order_result):
    client = boto3.client('ses')
    print(location + cuisine + num_of_people + email + date + time)
    
    #Make Email Content
    data_str = "Hello! Here are my " + cuisine + " restaurant suggestions for " + num_of_people + " people, for " + str(date) + " " + str(time) + ": "
    counter = 1
    for item in dinner_order_result:
        data_str += str(counter) + ". " + item[0] + ", located at " + item[1] + ". "
        counter = counter + 1
        
    data_str += " Enjoy your meal!"

    client.send_email(
    Source='jonathan.jsliu@gmail.com',
    Destination={
        'ToAddresses': [
            email,
        ]
    },
    Message={
        'Subject': {
            'Data': 'DiningOrder'
        },
        'Body': {
            'Text': {
                #'Data': location + cuisine + num_of_people + email + date + time
                'Data':data_str
            }
        }
    })
    #client.publish(PhoneNumber= phone, Message=location + cuisine + num_of_people + phone + date + time)




def lambda_handler(event, context):
    for record in event['Records']:
       print ("test")
       payload=record["body"]
       message = str(payload)
       messagelist = message.split('|')
       
       location = messagelist[0]
       cuisine = messagelist[1] # Used for elasticsearch
       num_of_people = messagelist[2]
       email = messagelist[3]
       date = messagelist[4]
       time = messagelist[5]
       
       business_ids = query_es(cuisine) # Get restaurant's business IDs from elasticsearch service.
       dinner_order_result = query_from_dynamodb(business_ids) # Get restaurant's name and address from DynamoDB.
       send_sms_message(location, cuisine, num_of_people, email, date, time, dinner_order_result)
       
    return None
